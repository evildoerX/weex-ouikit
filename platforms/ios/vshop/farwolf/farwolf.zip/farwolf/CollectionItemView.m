//
//  CollectionItemView.m
//  oa
//
//  Created by 郑江荣 on 16/5/6.
//  Copyright © 2016年 郑江荣. All rights reserved.
//

#import "CollectionItemView.h"

@implementation CollectionItemView
-(void)update:(NSObject*)n{
    
}
@end
