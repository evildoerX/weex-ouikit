//
//  ItemView.h
//  oa
//
//  Created by 郑江荣 on 16/3/15.
//  Copyright © 2016年 郑江荣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Screen.h"
@interface ItemView : UITableViewCell
-(void)update:(NSObject*)n;
@end
