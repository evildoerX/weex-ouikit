//
//  IndicatorItem.m
//  oa
//
//  Created by 郑江荣 on 2017/3/16.
//  Copyright © 2017年 郑江荣. All rights reserved.
//

#import "IndicatorItem.h"

@implementation IndicatorItem

-(void)select
{
    
}
-(void)unselect
{
    
}

@end
