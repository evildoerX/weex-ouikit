//
//  CircleView.h
//  oa
//
//  Created by 郑江荣 on 16/3/12.
//  Copyright © 2016年 郑江荣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIView+Farwolf.h"
@interface CircleView : UIView

@end
