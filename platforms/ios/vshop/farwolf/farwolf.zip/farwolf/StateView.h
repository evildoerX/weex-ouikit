//
//  StateView.h
//  oa
//
//  Created by 郑江荣 on 2017/3/30.
//  Copyright © 2017年 郑江荣. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StateView : UIView
-(void)setHeight:(CGFloat)height;
@end
