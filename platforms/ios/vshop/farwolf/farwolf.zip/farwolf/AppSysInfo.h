//
//  AppSysInfo.h
//  farwolf
//
//  Created by 郑江荣 on 2017/4/17.
//  Copyright © 2017年 郑江荣. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AppSysInfo : NSObject
+(NSString*)appName;
+(NSString*)versionName;

+(NSString*)version;
@end
