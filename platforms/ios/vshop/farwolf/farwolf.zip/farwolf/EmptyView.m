//
//  EmptyView.m
//  oa
//
//  Created by 郑江荣 on 16/5/5.
//  Copyright © 2016年 郑江荣. All rights reserved.
//

#import "EmptyView.h"

@implementation EmptyView

@end
