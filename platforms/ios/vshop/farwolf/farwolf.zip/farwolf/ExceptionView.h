//
//  ExceptionView.h
//  oa
//
//  Created by 郑江荣 on 16/5/5.
//  Copyright © 2016年 郑江荣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StateView.h"
@interface ExceptionView : StateView

@end
