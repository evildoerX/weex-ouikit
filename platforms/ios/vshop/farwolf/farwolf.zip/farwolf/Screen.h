//
//  Screen.h
//  oa
//
//  Created by 郑江荣 on 16/3/11.
//  Copyright © 2016年 郑江荣. All rights reserved.
//

#import <Foundation/Foundation.h>

static float SCREEN3_5=480.0;
static float SCREEN4_0=568.0;
static float SCREEN4_7=667.0;
static float SCREEN5_5=736.0;
//extern const float SCREEN3_5=480.0;
//extern const float SCREEN4_0=568.0;

@interface Screen : NSObject



@end
